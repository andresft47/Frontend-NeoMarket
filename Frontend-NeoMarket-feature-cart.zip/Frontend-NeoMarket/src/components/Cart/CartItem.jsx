import React from 'react';
import { Trash2, Plus, Minus } from 'lucide-react';
import { useCart } from '../../context/CartContext';

export const CartItem = ({ item }) => {
  const { removeItem, updateQty } = useCart();

  return (
    <li className="flex gap-4 py-4 border-b border-gray-100 last:border-0 group">
      {/* Imagen */}
      <div className="w-20 h-20 flex-shrink-0 rounded-xl overflow-hidden bg-gray-50 border border-gray-100">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-contain p-2 group-hover:scale-105 transition-transform duration-300"
        />
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <p className="text-xs text-gray-400 uppercase tracking-wider mb-0.5">{item.category}</p>
        <h4 className="text-sm font-semibold text-gray-900 line-clamp-2 leading-snug mb-2">
          {item.name}
        </h4>

        {/* Precio + controles */}
        <div className="flex items-center justify-between">
          <span className="text-sm font-bold text-gray-900">
            ${(item.price * item.quantity).toFixed(2)}
          </span>

          <div className="flex items-center gap-1">
            {/* Botón quitar / reducir */}
            <button
              onClick={() => updateQty(item.id, item.quantity - 1)}
              className="w-7 h-7 rounded-full bg-gray-100 hover:bg-primary-100 hover:text-primary-600
                flex items-center justify-center transition-colors"
              aria-label="Reducir cantidad"
            >
              {item.quantity === 1
                ? <Trash2 className="h-3.5 w-3.5 text-red-400" />
                : <Minus className="h-3.5 w-3.5" />
              }
            </button>

            <span className="w-6 text-center text-sm font-semibold text-gray-700">
              {item.quantity}
            </span>

            {/* Botón añadir */}
            <button
              onClick={() => updateQty(item.id, item.quantity + 1)}
              className="w-7 h-7 rounded-full bg-gray-100 hover:bg-primary-100 hover:text-primary-600
                flex items-center justify-center transition-colors"
              aria-label="Aumentar cantidad"
            >
              <Plus className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </li>
  );
};
