import React, { useEffect, useRef } from 'react';
import { X, ShoppingCart, Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { CartItem } from './CartItem';

export const CartDrawer = () => {
  const { items, isOpen, closeDrawer, totalItems, totalPrice, clearCart } = useCart();
  const drawerRef = useRef(null);

  // Cerrar con Escape
  useEffect(() => {
    const handleKey = (e) => { if (e.key === 'Escape') closeDrawer(); };
    if (isOpen) document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [isOpen, closeDrawer]);

  // Bloquear scroll del body cuando el drawer está abierto
  useEffect(() => {
    document.body.style.overflow = isOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  return (
    <>
      {/* Overlay */}
      <div
        onClick={closeDrawer}
        className={`fixed inset-0 bg-black/40 backdrop-blur-sm z-40 transition-opacity duration-300 ${
          isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        aria-hidden="true"
      />

      {/* Drawer panel */}
      <aside
        ref={drawerRef}
        aria-label="Carrito de compras"
        className={`fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-2xl z-50 flex flex-col
          transform transition-transform duration-300 ease-in-out
          ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <ShoppingCart className="h-5 w-5 text-primary-600" />
            <h2 className="text-lg font-bold text-gray-900">
              Mi Carrito
              {totalItems > 0 && (
                <span className="ml-2 text-sm font-medium text-gray-400">
                  ({totalItems} {totalItems === 1 ? 'producto' : 'productos'})
                </span>
              )}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            {items.length > 0 && (
              <button
                onClick={clearCart}
                className="text-xs text-gray-400 hover:text-red-500 transition-colors flex items-center gap-1 px-2 py-1 rounded hover:bg-red-50"
                title="Vaciar carrito"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Vaciar
              </button>
            )}
            <button
              onClick={closeDrawer}
              className="p-2 rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors"
              aria-label="Cerrar carrito"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Items list */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {items.length === 0 ? (
            <EmptyCart />
          ) : (
            <ul className="space-y-4">
              {items.map((item) => (
                <CartItem key={item.id} item={item} />
              ))}
            </ul>
          )}
        </div>

        {/* Footer con total y checkout */}
        {items.length > 0 && (
          <div className="border-t border-gray-100 px-6 py-5 space-y-4 bg-gray-50">
            {/* Desglose */}
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-gray-500">
                <span>Subtotal</span>
                <span>${totalPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-500">
                <span>Envío</span>
                <span className="text-green-600 font-medium">Gratis</span>
              </div>
              <div className="flex justify-between text-gray-900 font-bold text-base pt-2 border-t border-gray-200">
                <span>Total</span>
                <span>${totalPrice.toFixed(2)}</span>
              </div>
            </div>

            {/* Botón de checkout */}
            <button className="w-full bg-primary-600 text-white py-3.5 rounded-xl font-semibold
              hover:bg-primary-700 active:scale-95 transition-all duration-200
              flex items-center justify-center gap-2 shadow-md shadow-primary-200">
              Proceder al pago
              <ArrowRight className="h-4 w-4" />
            </button>

            <button
              onClick={closeDrawer}
              className="w-full text-center text-sm text-gray-500 hover:text-primary-600 transition-colors py-1"
            >
              Seguir comprando
            </button>
          </div>
        )}
      </aside>
    </>
  );
};

// ─── Estado vacío ─────────────────────────────────────────────────────────────
const EmptyCart = () => (
  <div className="flex flex-col items-center justify-center h-full text-center py-16">
    <div className="bg-gray-100 rounded-full p-6 mb-4">
      <ShoppingBag className="h-12 w-12 text-gray-300" />
    </div>
    <h3 className="text-lg font-semibold text-gray-700 mb-2">Tu carrito está vacío</h3>
    <p className="text-sm text-gray-400 max-w-xs">
      Agrega productos desde el catálogo para verlos aquí.
    </p>
  </div>
);
