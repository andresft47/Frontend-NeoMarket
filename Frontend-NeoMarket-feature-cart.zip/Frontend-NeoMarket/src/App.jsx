import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { AppRoutes } from './routes/AppRoutes';
import { CartProvider } from './context/CartContext';
import { CartDrawer } from './components/Cart/CartDrawer';

function App() {
  return (
    <CartProvider>
      <BrowserRouter>
        <AppRoutes />
        <CartDrawer />
      </BrowserRouter>
    </CartProvider>
  );
}

export default App;
