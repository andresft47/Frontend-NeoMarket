import React, { createContext, useContext, useReducer, useCallback } from 'react';

// ─── Estado inicial ───────────────────────────────────────────────────────────
const initialState = {
  items: [],          // [{ id, name, price, image, category, quantity }]
  isOpen: false,      // Drawer visible?
};

// ─── Reducer ──────────────────────────────────────────────────────────────────
function cartReducer(state, action) {
  switch (action.type) {

    case 'ADD_ITEM': {
      const existing = state.items.find(i => i.id === action.payload.id);
      if (existing) {
        return {
          ...state,
          items: state.items.map(i =>
            i.id === action.payload.id
              ? { ...i, quantity: i.quantity + 1 }
              : i
          ),
        };
      }
      return {
        ...state,
        items: [...state.items, { ...action.payload, quantity: 1 }],
      };
    }

    case 'REMOVE_ITEM':
      return {
        ...state,
        items: state.items.filter(i => i.id !== action.payload),
      };

    case 'UPDATE_QUANTITY': {
      const { id, quantity } = action.payload;
      if (quantity <= 0) {
        return { ...state, items: state.items.filter(i => i.id !== id) };
      }
      return {
        ...state,
        items: state.items.map(i =>
          i.id === id ? { ...i, quantity } : i
        ),
      };
    }

    case 'CLEAR_CART':
      return { ...state, items: [] };

    case 'OPEN_DRAWER':
      return { ...state, isOpen: true };

    case 'CLOSE_DRAWER':
      return { ...state, isOpen: false };

    case 'TOGGLE_DRAWER':
      return { ...state, isOpen: !state.isOpen };

    default:
      return state;
  }
}

// ─── Context ──────────────────────────────────────────────────────────────────
const CartContext = createContext(null);

// ─── Provider ─────────────────────────────────────────────────────────────────
export const CartProvider = ({ children }) => {
  const [state, dispatch] = useReducer(cartReducer, initialState);

  // Derivados
  const totalItems = state.items.reduce((sum, i) => sum + i.quantity, 0);
  const totalPrice = state.items.reduce((sum, i) => sum + i.price * i.quantity, 0);

  // Acciones memoizadas
  const addItem    = useCallback((product) => dispatch({ type: 'ADD_ITEM', payload: product }), []);
  const removeItem = useCallback((id)      => dispatch({ type: 'REMOVE_ITEM', payload: id }), []);
  const updateQty  = useCallback((id, qty) => dispatch({ type: 'UPDATE_QUANTITY', payload: { id, quantity: qty } }), []);
  const clearCart  = useCallback(()        => dispatch({ type: 'CLEAR_CART' }), []);
  const openDrawer  = useCallback(()       => dispatch({ type: 'OPEN_DRAWER' }), []);
  const closeDrawer = useCallback(()       => dispatch({ type: 'CLOSE_DRAWER' }), []);
  const toggleDrawer = useCallback(()      => dispatch({ type: 'TOGGLE_DRAWER' }), []);

  return (
    <CartContext.Provider value={{
      items: state.items,
      isOpen: state.isOpen,
      totalItems,
      totalPrice,
      addItem,
      removeItem,
      updateQty,
      clearCart,
      openDrawer,
      closeDrawer,
      toggleDrawer,
    }}>
      {children}
    </CartContext.Provider>
  );
};

// ─── Hook personalizado ───────────────────────────────────────────────────────
export const useCart = () => {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart debe usarse dentro de <CartProvider>');
  return ctx;
};
